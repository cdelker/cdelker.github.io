from .mathtable import MathTable
from .styles import styledchr, styledstr
from .zmath import Math, Text
from .config import config

__version__ = '0.7-alpha'