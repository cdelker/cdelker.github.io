''' The default canvas to draw on '''

default_canvas = 'matplotlib'
